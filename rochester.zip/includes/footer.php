 
 <a href="https://wa.me/+918590085591?text=I%20am%20interested%20in%20doing%20a%20course%20" class="btn-whatsapp-pulse">
    <i class="fab fa-whatsapp"></i>
</a>

</i>
</a>

 <!--Main Footer-->
    <footer class="main-footer" style="background-image: url(images/footer-skyline-background.jpg);">
    	<!--Widgets Section-->
    	<div class="widgets-section">
        	<div class="auto-container">
            	<div class="row clearfix">
                	<!--Big Column-->
                	<div class="big-column col-md-12 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                        
                        	<!--Footer Column-->
                        	<div class="footer-column col-md-4 col-sm-6 col-xs-12">
                            	<!--About Widget-->
                                <div class="footer-widget about-widget">
                                	<div class="footer-logo">
                                    	<a href="index.php"><img src="images/a2zlogo.png" alt="" /></a>
                                    </div>
                                	<div class="widget-content">
                                    	<div class="bold-text">Our School Specialists!</div>
                                        <div class="text">A2Z offers world class practical as well as<br> theoritical exposure to our students in a<br> friendly way to teaching.</div>
                                        <!--<a href="#" class="read-more">Read More...</a>-->
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-4 col-sm-6 col-xs-12">
                            	<!--Info Widget-->
                                <div class="footer-widget info-widget">
                                	<h2>Keep in Touch</h2>
                                    <div class="widget-content">
										<ul class="list-style-one">
                                        	<li><span class="icon flaticon-location-pin"></span>Mattancherry Halt, Kochi CPSA<br>Building , CIFT Junction , W. Island<br>Kochi Pin- 682029</li>
                                            <li><span class="icon flaticon-technology-3"></span>8590085591, 9605885591</li>
                                            <li><span class="icon flaticon-interface"></span>mail@a2zinstituteofheavyequipments.com
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <!--Footer Column-->
                        	<div class="footer-column col-md-4 col-sm-6 col-xs-12">
                            	<div class="footer-widget subscribe-widget">
                                    <h2>Courses Offered</h2>
                                    <div class="widget-content">
                                        <ul class="list-style-one">
                                            <li style="padding: 0px;margin-bottom: 12px;"><i class="fa fa-angle-double-right" style="padding-right: 22px;color: #fff;"  aria-hidden="true"></i><a style="color: #aba2a1;" href="mobile-crane.php">Mobile Crane</a></li>
                                            <li style="padding: 0px;margin-bottom: 12px;"><i class="fa fa-angle-double-right" style="padding-right: 22px;color: #fff;"  aria-hidden="true"></i><a style="color: #aba2a1;" href="hydra-crane.php">Hydra Crane</a></li>
                                            <li style="padding: 0px;margin-bottom: 12px;"><i class="fa fa-angle-double-right" style="padding-right: 22px;color: #fff;"  aria-hidden="true"></i><a style="color: #aba2a1;" href="rough-crane.php">Rough Terrain Crane</a></li>
                                            <li style="padding: 0px;margin-bottom: 12px;"><i class="fa fa-angle-double-right" style="padding-right: 22px;color: #fff;"  aria-hidden="true"></i><a style="color: #aba2a1;" href="tower-crane.php">Tower Crane</a></li>
                                            <li style="padding: 0px;margin-bottom: 12px;"><i class="fa fa-angle-double-right" style="padding-right: 22px;color: #fff;"  aria-hidden="true"></i><a style="color: #aba2a1;" href="mobile-tower-crane.php">Mobile Tower Crane</a></li>
                                            <li style="padding: 0px;margin-bottom: 12px;"><i class="fa fa-angle-double-right" style="padding-right: 22px;color: #fff;"  aria-hidden="true"></i><a style="color: #aba2a1;" href="rigging.php">Rigging</a></li>
                                        </ul>
                                    </div>
                                </div>
							</div>
                            
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                        	
                            
                            
                            
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--Footer Bottom-->
        <div class="footer-bottom">
        	<div class="auto-container" style="    padding: 0px 5px !important;">
            	<div class="row clearfix">
                	<div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="copyright">&copy; Copyright 2021 A2Z | All Rights Reserved</div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<ul class="social-links-two">
                            <li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                            <li><a href="#"><span class="fab fa-youtube"></span></a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Main Footer-->