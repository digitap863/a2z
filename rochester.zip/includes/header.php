 <!-- Main Header-->
     <header class="main-header">
        
        <!-- Header Top -->
        <!--<div class="header-top">
            <div class="auto-container clearfix">-->
                <!--Top Left-->
                <!--<div class="top-left pull-left">-->
                    
                    <!--Social Icon-->
                    <!--<div class="social-icon">
                        <a href="#"><span class="fa fa-facebook"></span></a>
                        <a href="#"><span class="fa fa-twitter"></span></a>
                        <a href="#"><span class="fa fa-pinterest"></span></a>
                        <a href="#"><span class="fa fa-google-plus"></span></a>
                    </div>
                    
                    <div class="contact-number"><span>CALL US NOW</span> <a href="#">: 1800 123 4567</a></div>
                </div>-->
                
                <!--Top Right-->
                <!--<div class="top-right pull-right">
                    <ul class="links-nav clearfix">
                        <li class="language dropdown"><a class="btn btn-default dropdown-toggle" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" href="#">EN &ensp;<span class="icon fa fa-caret-down"></span></a>
                            <ul class="dropdown-menu style-one" aria-labelledby="dropdownMenu2">
                                <li><a href="#">English</a></li>
                                <li><a href="#">German</a></li>
                                <li><a href="#">Arabic</a></li>
                                <li><a href="#">Hindi</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Login</a></li>
                        <li><a href="#">Register</a></li>
                    </ul>
                </div>-->
            <!--</div>
        </div>-->
        <!-- Header Top End -->
        
        <!--Header-Upper-->
        <div style="background-color: black;" class="header-upper">
            <div class="auto-container">
                <div class="clearfix">
                    
                    <div class="pull-left logo-outer">
                        <div class="logo"><a href="index.php"><img src="images/a2zlogo.png" alt="" title=""></a></div>
                    </div>
                    
                    <div class="nav-outer clearfix">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->      
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                            </div>
                            
                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li ><a href="index.php">Home</a>
                                        <!--<ul>
                                            <li><a href="index.php">Homepage One</a></li>
                                            <li><a href="index-2.html">Homepage Two</a></li>
                                            <li><a href="index-3.html">Homepage Three</a></li>
                                            <li class="dropdown"><a href="#">Header Styles</a>
                                                <ul>
                                                    <li><a href="index.php">Header Style One</a></li>
                                                    <li><a href="index-2.html">Header Style Two</a></li>
                                                    <li><a href="index-3.html">Header Style Three</a></li>
                                                </ul>
                                            </li>
                                        </ul>-->
                                    </li>
                                    <li ><a href="about.php">About Us</a>
                                        <!--<ul>
                                            <li><a href="about.php">About Type 01</a></li>
                                            <li><a href="about-two.html">About Type 02</a></li>
                                        </ul>-->
                                    </li>
                                    <li class="current dropdown"><a href="#">COURSES</a>
                                        <ul>
                                            <li><a href="mobile-crane.php">Mobile Crane</a></li>
                                            <li><a href="hydra-crane.php">Hydra Crane</a></li>
                                            <li><a href="rough-crane.php">Rough Terrain Crane</a></li>
                                            <li><a href="tower-crane.php">Tower Crane</a></li>
                                            <li><a href="mobile-tower-crane.php">Mobile Tower Crane</a></li>
                                            <li><a href="rigging.php">Rigging</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li ><a href="gallery.php">Gallery</a>
                                        <!--<ul>
                                            <li><a href="gallery.php">Gallery Three Column</a></li>
                                            <li><a href="gallery-fullwidth.html">Gallery Full Width</a></li>
                                        </ul>-->
                                    </li>
                                    
                                    
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--End Header Upper-->
        
        <!--Sticky Header-->
        <div style="background-color: black;" class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.php" class="img-responsive"><img src="images/a2zlogosmall.png" alt="" title=""></a>
                </div>
                
                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->      
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li ><a href="index.php">Home</a>
                                    <!--<ul>
                                        <li><a href="index.php">Homepage One</a></li>
                                        <li><a href="index-2.html">Homepage Two</a></li>
                                        <li><a href="index-3.html">Homepage Three</a></li>
                                        <li class="dropdown"><a href="#">Header Styles</a>
                                            <ul>
                                                <li><a href="index.php">Header Style One</a></li>
                                                <li><a href="index-2.html">Header Style Two</a></li>
                                                <li><a href="index-3.html">Header Style Three</a></li>
                                            </ul>
                                        </li>
                                    </ul>-->
                                </li>
                                <li ><a href="about.php">About Us</a>
                                    <!--<ul>
                                        <li><a href="about.php">About Type 01</a></li>
                                        <li><a href="about-two.html">About Type 02</a></li>
                                    </ul>-->
                                </li>
                                <li class="current dropdown"><a href="#">COURSES</a>
                                    <ul>
                                        <li><a href="mobile-crane.php">Mobile Crane</a></li>
                                        <li><a href="hydra-crane.php">Hydra Crane</a></li>
                                        <li><a href="rough-crane.php">Rough Terrain Crane</a></li>
                                        <li><a href="tower-crane.php">Tower Crane</a></li>
                                        <li><a href="mobile-tower-crane.php">Mobile Tower Crane</a></li>
                                        <li><a href="rigging.php">Rigging</a></li>
                                    </ul>
                                </li>
                                
                                <li ><a href="gallery.php">Gallery</a>
                                    <!--<ul>
                                        <li><a href="gallery.php">Gallery Three Column</a></li>
                                        <li><a href="gallery-fullwidth.html">Gallery Full Width</a></li>
                                    </ul>-->
                                </li>
                                
                                
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
                
            </div>
        </div>
        <!--End Sticky Header-->
    
    </header>
    <!--End Main Header -->