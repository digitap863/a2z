<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Rochester - Driving School HTML Template | About Us Two</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/jquery-ui.css" rel="stylesheet">
<!--Favicon-->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="css/responsive.css" rel="stylesheet">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <!-- Main Header-->
    <header class="main-header">
        
        <!-- Header Top -->
    	<div class="header-top">
        	<div class="auto-container clearfix">
            	<!--Top Left-->
            	<div class="top-left pull-left">
                	
                    <!--Social Icon-->
                	<div class="social-icon">
                        <a href="#"><span class="fa fa-facebook"></span></a>
                        <a href="#"><span class="fa fa-twitter"></span></a>
                        <a href="#"><span class="fa fa-pinterest"></span></a>
                        <a href="#"><span class="fa fa-google-plus"></span></a>
                    </div>
                    
                    <div class="contact-number"><span>CALL US NOW</span> <a href="#">: 1800 123 4567</a></div>
                </div>
                
                <!--Top Right-->
            	<div class="top-right pull-right">
                	<ul class="links-nav clearfix">
                    	<li class="language dropdown"><a class="btn btn-default dropdown-toggle" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" href="#">EN &ensp;<span class="icon fa fa-caret-down"></span></a>
                        	<ul class="dropdown-menu style-one" aria-labelledby="dropdownMenu2">
                                <li><a href="#">English</a></li>
                                <li><a href="#">German</a></li>
                                <li><a href="#">Arabic</a></li>
                                <li><a href="#">Hindi</a></li>
                            </ul>
                        </li>
                    	<li><a href="#">Login</a></li>
                        <li><a href="#">Register</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Header Top End -->
        
        <!--Header-Upper-->
        <div class="header-upper">
        	<div class="auto-container">
            	<div class="clearfix">
                	
                	<div class="pull-left logo-outer">
                    	<div class="logo"><a href="index.html"><img src="images/logo.png" alt="" title=""></a></div>
                    </div>
                    
                    <div class="nav-outer clearfix">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->    	
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                            </div>
                            
                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li class="dropdown"><a href="#">Home</a>
                                        <ul>
                                            <li><a href="index.html">Homepage One</a></li>
                                            <li><a href="index-2.html">Homepage Two</a></li>
                                            <li><a href="index-3.html">Homepage Three</a></li>
                                            <li class="dropdown"><a href="#">Header Styles</a>
                                                <ul>
                                                    <li><a href="index.html">Header Style One</a></li>
                                                    <li><a href="index-2.html">Header Style Two</a></li>
                                                    <li><a href="index-3.html">Header Style Three</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="current dropdown"><a href="#">About Us</a>
                                        <ul>
                                            <li><a href="about.html">About Type 01</a></li>
                                            <li><a href="about-two.html">About Type 02</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">INSTRUCTORS</a>
                                        <ul>
                                            <li><a href="instructor.html">Instructor</a></li>
                                            <li><a href="instructor-detail.html">Instructor Detail</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">Pages</a>
                                        <ul>
                                        	<li><a href="features.html">Features</a></li>
                                            <li><a href="price.html">Pricing</a></li>
                                            <li><a href="error-page.html">404 Page</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">Gallery</a>
                                        <ul>
                                        	<li><a href="gallery.html">Gallery Three Column</a></li>
                                            <li><a href="gallery-fullwidth.html">Gallery Full Width</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li class="dropdown"><a href="#">Blog</a>
                                        <ul>
                                        	<li><a href="blog-grid.html">Blog Grid View</a></li>
                                            <li><a href="blog-classic.html">Blog Classic View</a></li>
                                            <li><a href="blog-single.html">Blog Single</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--End Header Upper-->
        
        <!--Sticky Header-->
        <div class="sticky-header">
        	<div class="auto-container clearfix">
            	<!--Logo-->
            	<div class="logo pull-left">
                	<a href="index.html" class="img-responsive"><img src="images/logo-small.png" alt="" title=""></a>
                </div>
                
                <!--Right Col-->
                <div class="right-col pull-right">
                	<!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->    	
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="dropdown"><a href="#">Home</a>
                                    <ul>
                                        <li><a href="index.html">Homepage One</a></li>
                                        <li><a href="index-2.html">Homepage Two</a></li>
                                        <li><a href="index-3.html">Homepage Three</a></li>
                                        <li class="dropdown"><a href="#">Header Styles</a>
                                            <ul>
                                                <li><a href="index.html">Header Style One</a></li>
                                                <li><a href="index-2.html">Header Style Two</a></li>
                                                <li><a href="index-3.html">Header Style Three</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="current dropdown"><a href="#">About Us</a>
                                    <ul>
                                        <li><a href="about.html">About Type 01</a></li>
                                        <li><a href="about-two.html">About Type 02</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">INSTRUCTORS</a>
                                    <ul>
                                        <li><a href="instructor.html">Instructor</a></li>
                                        <li><a href="instructor-detail.html">Instructor Detail</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">Pages</a>
                                    <ul>
                                        <li><a href="features.html">Features</a></li>
                                        <li><a href="price.html">Pricing</a></li>
                                        <li><a href="error-page.html">404 Page</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">Gallery</a>
                                    <ul>
                                        <li><a href="gallery.html">Gallery Three Column</a></li>
                                        <li><a href="gallery-fullwidth.html">Gallery Full Width</a></li>
                                    </ul>
                                </li>
                                
                                <li class="dropdown"><a href="#">Blog</a>
                                    <ul>
                                        <li><a href="blog-grid.html">Blog Grid View</a></li>
                                        <li><a href="blog-classic.html">Blog Classic View</a></li>
                                        <li><a href="blog-single.html">Blog Single</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
                
            </div>
        </div>
        <!--End Sticky Header-->
    
    </header>
    <!--End Main Header -->
    
    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/3.jpg)">
    	<div class="auto-container">
        	<h2>About Us</h2>
            <ul class="bread-crumb clearfix">
                <li><a href="index.html">Home</a></li>
                <li class="active">About</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
    
    <!--Why Us Section-->
    <section class="why-us-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Content Column-->
            	<div class="content-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-box">
                    	<!--Sec Title-->
                        <div class="sec-title">
                        	<div class="title">Who We Are</div>
                            <h2>Why Choose Us</h2>
                            <div class="separator"></div>
                            <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per idunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. </div>
                            <div class="row clearfix">
                            	<ul class="list-style-two col-md-6 col-sm-6 col-xs-12">
                                	<li>Safety Driving</li>
                                    <li>Following Rules & Regulations</li>
                                    <li>Standard vehicles</li>
                                </ul>
                                <ul class="list-style-two col-md-6 col-sm-6 col-xs-12">
                                	<li>Traffic Rules </li>
                                    <li>Special classes</li>
                                    <li>Experience Instructors</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Image Column-->
                <div class="image-column col-md-6 col-sm-12 col-xs-12">
                	<div class="image wow slideInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<img src="images/resource/why-us.png" alt="" />
                    </div>
                </div>
            </div>
        </div>
        <!--Services Section-->
        <section class="services-section no-margin">
            <div class="auto-container">
                <div class="clearfix">
                    <!--Services Block-->
                    <div class="services-block column col-md-3 col-sm-6 col-xs-12">
                        <div class="inner">
                            <a href="#" class="overlay-link"></a>
                            <h3><span class="icon flaticon-steering-wheel-1"></span> Comfort Vehicles</h3>
                        </div>
                    </div>
                    <!--Services Block-->
                    <div class="services-block column col-md-3 col-sm-6 col-xs-12">
                        <div class="inner">
                            <a href="#" class="overlay-link"></a>
                            <h3><span class="icon flaticon-credit-card-1"></span> Licensed Training</h3>
                        </div>
                    </div>
                    <!--Services Block-->
                    <div class="services-block column col-md-3 col-sm-6 col-xs-12">
                        <div class="inner">
                            <a href="#" class="overlay-link"></a>
                            <h3><span class="icon flaticon-gearbox"></span> Driving Practice</h3>
                        </div>
                    </div>
                    <!--Services Block-->
                    <div class="services-block column col-md-3 col-sm-6 col-xs-12">
                        <div class="inner">
                            <a href="#" class="overlay-link"></a>
                            <h3><span class="icon flaticon-vehicle-speedometer"></span> Flexible Schedule</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Services Section-->
    </section>
    <!--End Why Us Section-->
    
    <!--FullWisth Section Three-->
    <section class="fullwidth-section-three">
    	<div class="outer-box clearfix">
        	<!--Image Column-->
        	<div class="image-column" style="background-image:url(images/resource/fullwith-3.jpg);">
        		<div class="image-box">
                    <img src="images/resource/fullwith-3.jpg" alt="" />
                </div>
            </div>
            <!--Services Column-->
            <div class="services-column">
            	<div class="inner">
                	<div class="testimonial-carousel owl-carousel owl-theme">
                    
                		<!--Testimonial Slide-->
                        <div class="testimonial-slide">
                            <!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-people-1"></span>
                                    </div>
                                    <h3><a href="#">Instructor Training</a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                            <!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-gearbox"></span>
                                    </div>
                                    <h3><a href="#">Highway Safety</a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                            <!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-traffic-light-1"></span>
                                    </div>
                                    <h3><a href="#">Traffic Rules </a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                        </div>
                        
                        <!--Testimonial Slide-->
                        <div class="testimonial-slide">
                        	<!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-traffic-light-1"></span>
                                    </div>
                                    <h3><a href="#">Traffic Rules </a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                            <!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-people-1"></span>
                                    </div>
                                    <h3><a href="#">Instructor Training</a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                            <!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-gearbox"></span>
                                    </div>
                                    <h3><a href="#">Highway Safety</a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                        </div>
                        
                        <!--Testimonial Slide-->
                        <div class="testimonial-slide">
                        	<!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-gearbox"></span>
                                    </div>
                                    <h3><a href="#">Highway Safety</a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                            <!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-people-1"></span>
                                    </div>
                                    <h3><a href="#">Instructor Training</a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                            <!--Testimonial Block Two-->
                            <div class="testimonial-block-two">
                                <div class="testimonial-inner">
                                    <div class="icon-box">
                                        <span class="icon flaticon-traffic-light-1"></span>
                                    </div>
                                    <h3><a href="#">Traffic Rules </a></h3>
                                    <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odiomsan ipsum velit.</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!--Form Column-->
            <div class="form-column">
            	<div class="form-inner">
            		<h3>Application Form</h3>
                    
                    <!--Default Form-->
                    <div class="default-form">
                        <form method="post">
                            <div class="row clearfix">
                            
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <div class="group-inner">
                                        <label class="icon-label" for="field-one"><span class="fa fa-user"></span></label>
                                        <input id="field-one" type="text" name="username" value="" placeholder="Your Name" required>
                                    </div>
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <div class="group-inner">
                                        <label class="icon-label" for="field-two"><span class="fa fa-envelope-o"></span></label>
                                        <input id="field-two" type="email" name="email" value="" placeholder="Email" required>
                                    </div>
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <div class="group-inner">
                                        <label class="icon-label" for="field-three"><span class="fa fa-phone"></span></label>
                                        <input id="field-three" type="text" name="phone" placeholder="Phone">
                                    </div>
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <div class="group-inner">
                                        <label class="icon-label" for="field-four"><span class="fa fa-calendar"></span></label>
                                        <input id="field-four" type="text" name="date-time" class="datetimepicker" value="" placeholder="Date and Time" required>
                                    </div>
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <div class="group-inner">
                                        <label class="icon-label" for="field-five"><span class="fa fa-file-text-o"></span></label>
                                        <select id="field-five" class="custom-select-box">
                                        	<option>Course Type</option>
                                            <option>Type 1</option>
                                            <option>Type 2</option>
                                            <option>Type 3</option>
                                        </select>
                                    </div>
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <div class="group-inner">
                                        <label class="icon-label" for="field-six"><span class="fa fa-car"></span></label>
                                        <select id="field-six" class="custom-select-box">
                                        	<option>Car Type</option>
                                            <option>Honda</option>
                                            <option>City</option>
                                            <option>Rebon</option>
                                        </select>
                                    </div>
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <button type="submit" class="theme-btn btn-style-one">SEND INQUIRY</button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                    <!--End Inquiry Form-->
                    
                </div>
            </div>
        </div>
    </section>
    <!--End FullWisth Section Three-->
    
    <!--Instructor Section Two-->
    <section class="fullwidth-section-two">
    	<div class="outer-box clearfix">
        	<!--Left Column-->
        	<div class="left-column">
            	<div class="content">
                	<!--Sec Title-->
                    <div class="sec-title">
                    	<div class="title">Our Great Team</div>
                        <h2>Our Instructors</h2>
                        <div class="separator"></div>
                    </div>
                    <div class="single-item-carousel owl-carousel owl-theme">
                    
                    	<div class="slide-item">
                            <!--Sec Title Small-->
                            <div class="sec-title-small">
                                <h2><a href="instructor-detail.html">David Warner</a></h2>
                                <div class="title">Instructor</div>
                                <div class="separator"></div>
                            </div>
                            <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti soconubia nostra.</div>
                            <ul class="social-links-four">
                                <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            </ul>
                            <!--Skills Box-->
                            <div class="skills-box">
                                <h3>Skills</h3>
                                
                                <!--Progress Levels-->
                                <div class="skill-progress">
            
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:80%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Teaching</div>
                                    </div>
            
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:70%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Instructing</div>
                                    </div>
                                    
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:90%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Driving</div>
                                    </div>
            
                                </div>
                            
                        	</div>
                        </div>
                        
                        <div class="slide-item">
                            <!--Sec Title Small-->
                            <div class="sec-title-small">
                                <h2><a href="instructor-detail.html">David Warner</a></h2>
                                <div class="title">Instructor</div>
                                <div class="separator"></div>
                            </div>
                            <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti soconubia nostra.</div>
                            <ul class="social-links-four">
                                <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            </ul>
                            <!--Skills Box-->
                            <div class="skills-box">
                                <h3>Skills</h3>
                                
                                <!--Progress Levels-->
                                <div class="skill-progress">
            
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:80%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Teaching</div>
                                    </div>
            
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:70%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Instructing</div>
                                    </div>
                                    
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:90%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Driving</div>
                                    </div>
            
                                </div>
                            
                        	</div>
                        </div>
                        
                        <div class="slide-item">
                            <!--Sec Title Small-->
                            <div class="sec-title-small">
                                <h2><a href="instructor-detail.html">David Warner</a></h2>
                                <div class="title">Instructor</div>
                                <div class="separator"></div>
                            </div>
                            <div class="text">Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti soconubia nostra.</div>
                            <ul class="social-links-four">
                                <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            </ul>
                            <!--Skills Box-->
                            <div class="skills-box">
                                <h3>Skills</h3>
                                
                                <!--Progress Levels-->
                                <div class="skill-progress">
            
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:80%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Teaching</div>
                                    </div>
            
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:70%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Instructing</div>
                                    </div>
                                    
                                    <!--Skill Box-->
                                    <div class="skill clearfix">
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-inner"><div class="filled-bar" style="width:90%;"></div></div>
                                            </div>
                                        </div>
                                        <div class="box-title">Driving</div>
                                    </div>
            
                                </div>
                            
                        	</div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!--Image Column-->
        	<div class="image-column" style="background-image:url(images/resource/fullwith-2.jpg);">
            	<div class="hidden-image">
                	<img src="images/resource/fullwith-2.jpg" alt="" />
                </div>
			</div>
            
        </div>
    </section>
    <!--End Instructor Section Two-->
    
    <!--Fun Facts Section -->
    <section class="fun-facts-section" style="background-image:url(images/background/1.jpg);">
    	<div class="auto-container">
            
            <div class="row clearfix">
            	<!--Column-->
                <div class="column count-box col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="inner">
                    	<div class="icon-box"><span class="flaticon-mortarboard-1"></span></div>
                        <div class="content">
                            <div class="count-outer">
                                <span class="count-text" data-speed="3000" data-stop="9.5">0</span>
                                <span class="plus">K</span>
                            </div>
                            <div class="counter-title">Graduates</div>
                        </div>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column count-box col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="inner">
                    	<div class="icon-box"><span class="flaticon-people-1"></span></div>
                        <div class="content">
                            <div class="count-outer">
                                <span class="count-text" data-speed="2000" data-stop="35">0</span>
                            </div>
                            <div class="counter-title">Teachers</div>
                        </div>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column count-box col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="inner">
                    	<div class="icon-box"><span class="flaticon-transport-1"></span></div>
                        <div class="content">
                            <div class="count-outer">
                                <span class="count-text" data-speed="4000" data-stop="557">0</span>
                            </div>
                            <div class="counter-title">Own Vehicles</div>
                        </div>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column count-box col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="inner">
                    	<div class="icon-box"><span class="flaticon-dashboard"></span></div>
                        <div class="content">
                            <div class="count-outer">
                                <span class="count-text" data-speed="3000" data-stop="15">0</span>
                            </div>
                            <div class="counter-title">Years Of Market</div>
                        </div>
                    </div>
                </div>
                    
            </div>
            
        </div>
    </section>
	<!--Fun Facts Section -->
    
    <!--Default Section-->
    <section class="default-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            
            	<!--Testimonial Column-->
            	<div class="testimonial-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-box">
                    	<div class="sec-title">
                        	<div class="title">Clients Feedback</div>
                			<h2>Testimonials</h2>
                			<div class="separator"></div>
                        </div>
                        <div class="single-item-carousel owl-carousel owl-theme">
                            <!--Testimonial Block-->
                            <div class="testimonial-block">
                                <div class="inner">
                                    <div class="author-info">
                                        <div class="author-image"><img src="images/resource/author-1.jpg" alt="" /></div>
                                        <h3>Benjamin Blanchard</h3>
                                        <div class="designation">( CEO & Founder OF School )</div>
                                        <div class="rating"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star-half-full"></span></div>
                                    </div>
                                    <div class="text">people who already have strong trust relshipasdzes with you akshay. this is photoshop’s version akshay lorad aem ipsuasdm. proin gravida nibh vel velit auctor aliquet. awho already have strong trust.people whcao already have ssatrong trust relships with you akshay. this is photoshop’s version akshaetsy lorem ipsum. proin gravida nibh vel velit auctor aliquet. </div>
                                    <div class="signature"><img src="images/resource/signature.png" alt="" /></div>
                                </div>
                            </div>
                            <!--Testimonial Block-->
                            <div class="testimonial-block">
                                <div class="inner">
                                    <div class="author-info">
                                        <div class="author-image"><img src="images/resource/author-1.jpg" alt="" /></div>
                                        <h3>Benjamin Blanchard</h3>
                                        <div class="designation">( CEO & Founder OF School )</div>
                                        <div class="rating"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star-half-full"></span></div>
                                    </div>
                                    <div class="text">people who already have strong trust relshipasdzes with you akshay. this is photoshop’s version akshay lorad aem ipsuasdm. proin gravida nibh vel velit auctor aliquet. awho already have strong trust.people whcao already have ssatrong trust relships with you akshay. this is photoshop’s version akshaetsy lorem ipsum. proin gravida nibh vel velit auctor aliquet. </div>
                                    <div class="signature"><img src="images/resource/signature.png" alt="" /></div>
                                </div>
                            </div>
                            <!--Testimonial Block-->
                            <div class="testimonial-block">
                                <div class="inner">
                                    <div class="author-info">
                                        <div class="author-image"><img src="images/resource/author-1.jpg" alt="" /></div>
                                        <h3>Benjamin Blanchard</h3>
                                        <div class="designation">( CEO & Founder OF School )</div>
                                        <div class="rating"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star-half-full"></span></div>
                                    </div>
                                    <div class="text">people who already have strong trust relshipasdzes with you akshay. this is photoshop’s version akshay lorad aem ipsuasdm. proin gravida nibh vel velit auctor aliquet. awho already have strong trust.people whcao already have ssatrong trust relships with you akshay. this is photoshop’s version akshaetsy lorem ipsum. proin gravida nibh vel velit auctor aliquet. </div>
                                    <div class="signature"><img src="images/resource/signature.png" alt="" /></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Accordian Column-->
                <div class="accordian-column col-md-6 col-sm-12 col-xs-12">
                	<div class="sec-title">
                        <div class="title">Frequently Asked Questions</div>
                        <h2>Ask Questions</h2>
                        <div class="separator"></div>
                    </div>
                    
                    <!--Accordion Box-->
                    <ul class="accordion-box">
                    	
                        <!--Block-->
                        <li class="accordion block active-block">
                            <div class="acc-btn active"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>There are many many variations of passages of Lorem Ipsum available?</div>
                            <div class="acc-content current">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
						
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin?</div>
                            <div class="acc-content">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
                        
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>Lessons From just $20 Lessons for $120 or 10 Hours For $180?</div>
                            <div class="acc-content">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
                        
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>Aenean sollicitudin, lorem quis bibendum onsequat ipsum, ?</div>
                            <div class="acc-content">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
						
                    </ul><!--End Accordion Box-->
                    
                </div>
                
            </div>
        </div>
    </section>
    <!--End Default Section-->
    
    <!--Main Footer-->
    <footer class="main-footer">
    	<!--Widgets Section-->
    	<div class="widgets-section">
        	<div class="auto-container">
            	<div class="row clearfix">
                	<!--Big Column-->
                	<div class="big-column col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                        
                        	<!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<!--About Widget-->
                                <div class="footer-widget about-widget">
                                	<div class="footer-logo">
                                    	<a href="index.html"><img src="images/logo-2.png" alt="" /></a>
                                    </div>
                                	<div class="widget-content">
                                    	<div class="bold-text">Our School Specialists!</div>
                                        <div class="text">Aorem ipsum dolor sit amet elit sed lum tempor incididunt ut labore el dolore alg minim veniam quis nostrud lorem psum dolor sit amet sed incididunt.</div>
                                        <a href="#" class="read-more">Read More...</a>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<!--Gallery Widget-->
                                <div class="footer-widget gallery-widget">
                                	<h2>Our Gallery</h2>
                                    <div class="widget-content">
                                    	<div class="images-outer clearfix">
                                            <!--Image Box-->
                                            <figure class="image-box"><a href="images/gallery/1.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-thumb-1.jpg" alt=""></a></figure>
                                            <!--Image Box-->
                                            <figure class="image-box"><a href="images/gallery/2.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-thumb-2.jpg" alt=""></a></figure>
                                            <!--Image Box-->
                                            <figure class="image-box"><a href="images/gallery/3.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-thumb-3.jpg" alt=""></a></figure>
                                            <!--Image Box-->
                                            <figure class="image-box"><a href="images/gallery/4.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-thumb-4.jpg" alt=""></a></figure>
                                            <!--Image Box-->
                                            <figure class="image-box"><a href="images/gallery/1.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-thumb-5.jpg" alt=""></a></figure>
                                            <!--Image Box-->
                                            <figure class="image-box"><a href="images/gallery/2.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-thumb-6.jpg" alt=""></a></figure>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                        	
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<!--Info Widget-->
                                <div class="footer-widget info-widget">
                                	<h2>Keep in Touch</h2>
                                    <div class="widget-content">
										<ul class="list-style-one">
                                        	<li><span class="icon flaticon-location-pin"></span>Collins Street West,121 <br> King Street, Melbourne.</li>
                                            <li><span class="icon flaticon-technology-3"></span>+(11)123 456 7890, </li>
                                            <li><span class="icon flaticon-interface"></span>info@drivingschool.com</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget subscribe-widget">
                                    <h2>News letter</h2>
                                    <div class="widget-content">
                                        <div class="newsletter-form">
                                            <form method="post" action="contact.html">
                                                <div class="form-group">
                                                    <input type="text" name="name" value="" placeholder="Name *" required="">
                                                </div>
                                                <div class="form-group">
                                                    <input type="email" name="email" value="" placeholder="Email Id" required="">
                                                </div>
                                                <div class="form-group">
                                                    <button type="submit" class="theme-btn btn-style-one">SUBSCRIBE</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
							</div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--Footer Bottom-->
        <div class="footer-bottom">
        	<div class="auto-container">
            	<div class="row clearfix">
                	<div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="copyright">&copy; Copyright 2017 DrivingSchool | All Rights Reserved</div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<ul class="social-links-two">
                            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
    </footer>
    <!--End Main Footer-->
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>
<script src="js/owl.js"></script>
<script src="js/appear.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/jquery.datetimepicker.js"></script>
<script src="js/script.js"></script>

</body>
</html>