<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Rochester - Driving School HTML Template | features</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<!--Favicon-->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="css/responsive.css" rel="stylesheet">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <!-- Main Header-->
    <header class="main-header">
        
        <!-- Header Top -->
    	<div class="header-top">
        	<div class="auto-container clearfix">
            	<!--Top Left-->
            	<div class="top-left pull-left">
                	
                    <!--Social Icon-->
                	<div class="social-icon">
                        <a href="#"><span class="fa fa-facebook"></span></a>
                        <a href="#"><span class="fa fa-twitter"></span></a>
                        <a href="#"><span class="fa fa-pinterest"></span></a>
                        <a href="#"><span class="fa fa-google-plus"></span></a>
                    </div>
                    
                    <div class="contact-number"><span>CALL US NOW</span> <a href="#">: 1800 123 4567</a></div>
                </div>
                
                <!--Top Right-->
            	<div class="top-right pull-right">
                	<ul class="links-nav clearfix">
                    	<li class="language dropdown"><a class="btn btn-default dropdown-toggle" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" href="#">EN &ensp;<span class="icon fa fa-caret-down"></span></a>
                        	<ul class="dropdown-menu style-one" aria-labelledby="dropdownMenu2">
                                <li><a href="#">English</a></li>
                                <li><a href="#">German</a></li>
                                <li><a href="#">Arabic</a></li>
                                <li><a href="#">Hindi</a></li>
                            </ul>
                        </li>
                    	<li><a href="#">Login</a></li>
                        <li><a href="#">Register</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Header Top End -->
        
        <!--Header-Upper-->
        <div class="header-upper">
        	<div class="auto-container">
            	<div class="clearfix">
                	
                	<div class="pull-left logo-outer">
                    	<div class="logo"><a href="index.html"><img src="images/logo.png" alt="" title=""></a></div>
                    </div>
                    
                    <div class="nav-outer clearfix">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->    	
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                            </div>
                            
                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li class="dropdown"><a href="#">Home</a>
                                        <ul>
                                            <li><a href="index.html">Homepage One</a></li>
                                            <li><a href="index-2.html">Homepage Two</a></li>
                                            <li><a href="index-3.html">Homepage Three</a></li>
                                            <li class="dropdown"><a href="#">Header Styles</a>
                                                <ul>
                                                    <li><a href="index.html">Header Style One</a></li>
                                                    <li><a href="index-2.html">Header Style Two</a></li>
                                                    <li><a href="index-3.html">Header Style Three</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">About Us</a>
                                        <ul>
                                            <li><a href="about.html">About Type 01</a></li>
                                            <li><a href="about-two.html">About Type 02</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">INSTRUCTORS</a>
                                        <ul>
                                            <li><a href="instructor.html">Instructor</a></li>
                                            <li><a href="instructor-detail.html">Instructor Detail</a></li>
                                        </ul>
                                    </li>
                                    <li class="current dropdown"><a href="#">Pages</a>
                                        <ul>
                                        	<li><a href="features.html">Features</a></li>
                                            <li><a href="price.html">Pricing</a></li>
                                            <li><a href="error-page.html">404 Page</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">Gallery</a>
                                        <ul>
                                        	<li><a href="gallery.html">Gallery Three Column</a></li>
                                            <li><a href="gallery-fullwidth.html">Gallery Full Width</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li class="dropdown"><a href="#">Blog</a>
                                        <ul>
                                        	<li><a href="blog-grid.html">Blog Grid View</a></li>
                                            <li><a href="blog-classic.html">Blog Classic View</a></li>
                                            <li><a href="blog-single.html">Blog Single</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--End Header Upper-->
        
        <!--Sticky Header-->
        <div class="sticky-header">
        	<div class="auto-container clearfix">
            	<!--Logo-->
            	<div class="logo pull-left">
                	<a href="index.html" class="img-responsive"><img src="images/logo-small.png" alt="" title=""></a>
                </div>
                
                <!--Right Col-->
                <div class="right-col pull-right">
                	<!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->    	
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="dropdown"><a href="#">Home</a>
                                    <ul>
                                        <li><a href="index.html">Homepage One</a></li>
                                        <li><a href="index-2.html">Homepage Two</a></li>
                                        <li><a href="index-3.html">Homepage Three</a></li>
                                        <li class="dropdown"><a href="#">Header Styles</a>
                                            <ul>
                                                <li><a href="index.html">Header Style One</a></li>
                                                <li><a href="index-2.html">Header Style Two</a></li>
                                                <li><a href="index-3.html">Header Style Three</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">About Us</a>
                                    <ul>
                                        <li><a href="about.html">About Type 01</a></li>
                                        <li><a href="about-two.html">About Type 02</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">INSTRUCTORS</a>
                                    <ul>
                                        <li><a href="instructor.html">Instructor</a></li>
                                        <li><a href="instructor-detail.html">Instructor Detail</a></li>
                                    </ul>
                                </li>
                                <li class="current dropdown"><a href="#">Pages</a>
                                    <ul>
                                        <li><a href="features.html">Features</a></li>
                                        <li><a href="price.html">Pricing</a></li>
                                        <li><a href="error-page.html">404 Page</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">Gallery</a>
                                    <ul>
                                        <li><a href="gallery.html">Gallery Three Column</a></li>
                                        <li><a href="gallery-fullwidth.html">Gallery Full Width</a></li>
                                    </ul>
                                </li>
                                
                                <li class="dropdown"><a href="#">Blog</a>
                                    <ul>
                                        <li><a href="blog-grid.html">Blog Grid View</a></li>
                                        <li><a href="blog-classic.html">Blog Classic View</a></li>
                                        <li><a href="blog-single.html">Blog Single</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
                
            </div>
        </div>
        <!--End Sticky Header-->
    
    </header>
    <!--End Main Header -->
    
    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/3.jpg)">
    	<div class="auto-container">
        	<h2>Our Features</h2>
            <ul class="bread-crumb clearfix">
                <li><a href="index.html">Home</a></li>
                <li class="active">Our Features</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
    
    <!--Featured Section-->
    <section class="featured-section">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<div class="title">Our Services</div>
                <h2>Our Features</h2>
                <div class="separator"></div>
                <div class="text">Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor.Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor.</div>
            </div>
        	<div class="row clearfix">
            	
                <!--Services Block Three-->
                <div class="services-block-three col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<div class="image">
                            	<img src="images/resource/services-1.jpg" alt="" />
                            </div>
                        </div>
                        <h3><a href="#">Driving Insurance</a></h3>
                        <div class="text">Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor.Proin gravida nibh vel velit auctor aliquet. </div>
                    </div>
                </div>
                
                <!--Services Block Three-->
                <div class="services-block-three col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<div class="image">
                            	<img src="images/resource/services-2.jpg" alt="" />
                            </div>
                        </div>
                        <h3><a href="#">Online Exams</a></h3>
                        <div class="text">Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor.Proin gravida nibh vel velit auctor aliquet. </div>
                    </div>
                </div>
                
                <!--Services Block Three-->
                <div class="services-block-three col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<div class="image">
                            	<img src="images/resource/services-3.jpg" alt="" />
                            </div>
                        </div>
                        <h3><a href="#">Heavey Practice</a></h3>
                        <div class="text">Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor.Proin gravida nibh vel velit auctor aliquet. </div>
                    </div>
                </div>
                
                <!--Services Block Three-->
                <div class="services-block-three col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image-box">
                        	<div class="image">
                            	<img src="images/resource/services-4.jpg" alt="" />
                            </div>
                        </div>
                        <h3><a href="#">Traffic Rules</a></h3>
                        <div class="text">Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor.Proin gravida nibh vel velit auctor aliquet. </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!--End Featured Section-->
    
    <!--Full Width Section-->
    <section class="fullwidth-section">
    	<div class="section-outer clearfix">
        	<!--Image Column-->
        	<div class="image-column" style="background-image:url(images/resource/fullwith-1.jpg);">
            	<div class="hidden-image">
                	<img src="images/resource/fullwith-1.jpg" alt="" />
                </div>
            </div>
            <!--Right Column-->
            <div class="right-column">
            	<div class="content">
                	<div class="tabs-box courses-tabs">
                    	<div class="buttons-outer">
                        	<ul class="tab-buttons">
                            	<li class="tab-btn active-btn" data-tab="#class-tab-1">Instructor Training</li>
                                <li class="tab-btn" data-tab="#class-tab-2">Highway Safety</li>
                                <li class="tab-btn" data-tab="#class-tab-3">Traffic Rules test</li>
                                <li class="tab-btn" data-tab="#class-tab-4">CONSULTATION</li>
                                <li class="tab-btn" data-tab="#class-tab-5">how to protect car</li>
                                <li class="tab-btn" data-tab="#class-tab-6">PRACTICE SKILLS</li>
                            </ul>
                        </div>
                        <div class="tabs-content">
                        	<!--Tab / Active tab-->
                        	<div class="tab active-tab" id="class-tab-1">
                            	<div class="content-box">
                                	<div class="data">
                                        <div class="icon flaticon-traffic-light-1"></div>
                                        <div class="separator"></div>
                                        <div class="price">Course Prize : <span>$200</span></div>
                                        <div class="text">You can choose your team on weekdays after work or on weekendswe take into account the age of individual momentsto everyone we have our own approach.practical training</div>
                                        <a href="#" class="book-now">Book Now &nbsp;<span class="arrow fa fa-angle-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Tab-->
                        	<div class="tab" id="class-tab-2">
                            	<div class="content-box">
                                	<div class="data">
                                        <div class="icon flaticon-traffic-light-1"></div>
                                        <div class="separator"></div>
                                        <div class="price">Course Prize : <span>$200</span></div>
                                        <div class="text">You can choose your team on weekdays after work or on weekendswe take into account the age of individual momentsto everyone we have our own approach.practical training</div>
                                        <a href="#" class="book-now">Book Now &nbsp;<span class="arrow fa fa-angle-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Tab-->
                        	<div class="tab" id="class-tab-3">
                            	<div class="content-box">
                                	<div class="data">
                                        <div class="icon flaticon-traffic-light-1"></div>
                                        <div class="separator"></div>
                                        <div class="price">Course Prize : <span>$200</span></div>
                                        <div class="text">You can choose your team on weekdays after work or on weekendswe take into account the age of individual momentsto everyone we have our own approach.practical training</div>
                                        <a href="#" class="book-now">Book Now &nbsp;<span class="arrow fa fa-angle-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Tab-->
                        	<div class="tab" id="class-tab-4">
                            	<div class="content-box">
                                	<div class="data">
                                        <div class="icon flaticon-traffic-light-1"></div>
                                        <div class="separator"></div>
                                        <div class="price">Course Prize : <span>$200</span></div>
                                        <div class="text">You can choose your team on weekdays after work or on weekendswe take into account the age of individual momentsto everyone we have our own approach.practical training</div>
                                        <a href="#" class="book-now">Book Now &nbsp;<span class="arrow fa fa-angle-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Tab-->
                        	<div class="tab" id="class-tab-5">
                            	<div class="content-box">
                                	<div class="data">
                                        <div class="icon flaticon-traffic-light-1"></div>
                                        <div class="separator"></div>
                                        <div class="price">Course Prize : <span>$200</span></div>
                                        <div class="text">You can choose your team on weekdays after work or on weekendswe take into account the age of individual momentsto everyone we have our own approach.practical training</div>
                                        <a href="#" class="book-now">Book Now &nbsp;<span class="arrow fa fa-angle-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Tab-->
                        	<div class="tab" id="class-tab-6">
                            	<div class="content-box">
                                	<div class="data">
                                        <div class="icon flaticon-traffic-light-1"></div>
                                        <div class="separator"></div>
                                        <div class="price">Course Prize : <span>$200</span></div>
                                        <div class="text">You can choose your team on weekdays after work or on weekendswe take into account the age of individual momentsto everyone we have our own approach.practical training</div>
                                        <a href="#" class="book-now">Book Now &nbsp;<span class="arrow fa fa-angle-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                	
                </div>
            </div>
		</div>
    </section>
    <!--End Full Width Section-->
	
    <!--Default Section-->
    <section class="default-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            
            	<!--Testimonial Column-->
            	<div class="testimonial-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-box">
                    	<div class="sec-title">
                        	<div class="title">Clients Feedback</div>
                			<h2>Testimonials</h2>
                			<div class="separator"></div>
                        </div>
                        <div class="single-item-carousel owl-carousel owl-theme">
                            <!--Testimonial Block-->
                            <div class="testimonial-block">
                                <div class="inner">
                                    <div class="author-info">
                                        <div class="author-image"><img src="images/resource/author-1.jpg" alt="" /></div>
                                        <h3>Benjamin Blanchard</h3>
                                        <div class="designation">( CEO & Founder OF School )</div>
                                        <div class="rating"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star-half-full"></span></div>
                                    </div>
                                    <div class="text">people who already have strong trust relshipasdzes with you akshay. this is photoshop’s version akshay lorad aem ipsuasdm. proin gravida nibh vel velit auctor aliquet. awho already have strong trust.people whcao already have ssatrong trust relships with you akshay. this is photoshop’s version akshaetsy lorem ipsum. proin gravida nibh vel velit auctor aliquet. </div>
                                    <div class="signature"><img src="images/resource/signature.png" alt="" /></div>
                                </div>
                            </div>
                            <!--Testimonial Block-->
                            <div class="testimonial-block">
                                <div class="inner">
                                    <div class="author-info">
                                        <div class="author-image"><img src="images/resource/author-1.jpg" alt="" /></div>
                                        <h3>Benjamin Blanchard</h3>
                                        <div class="designation">( CEO & Founder OF School )</div>
                                        <div class="rating"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star-half-full"></span></div>
                                    </div>
                                    <div class="text">people who already have strong trust relshipasdzes with you akshay. this is photoshop’s version akshay lorad aem ipsuasdm. proin gravida nibh vel velit auctor aliquet. awho already have strong trust.people whcao already have ssatrong trust relships with you akshay. this is photoshop’s version akshaetsy lorem ipsum. proin gravida nibh vel velit auctor aliquet. </div>
                                    <div class="signature"><img src="images/resource/signature.png" alt="" /></div>
                                </div>
                            </div>
                            <!--Testimonial Block-->
                            <div class="testimonial-block">
                                <div class="inner">
                                    <div class="author-info">
                                        <div class="author-image"><img src="images/resource/author-1.jpg" alt="" /></div>
                                        <h3>Benjamin Blanchard</h3>
                                        <div class="designation">( CEO & Founder OF School )</div>
                                        <div class="rating"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star-half-full"></span></div>
                                    </div>
                                    <div class="text">people who already have strong trust relshipasdzes with you akshay. this is photoshop’s version akshay lorad aem ipsuasdm. proin gravida nibh vel velit auctor aliquet. awho already have strong trust.people whcao already have ssatrong trust relships with you akshay. this is photoshop’s version akshaetsy lorem ipsum. proin gravida nibh vel velit auctor aliquet. </div>
                                    <div class="signature"><img src="images/resource/signature.png" alt="" /></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Accordian Column-->
                <div class="accordian-column col-md-6 col-sm-12 col-xs-12">
                	<div class="sec-title">
                        <div class="title">Frequently Asked Questions</div>
                        <h2>Ask Questions</h2>
                        <div class="separator"></div>
                    </div>
                    
                    <!--Accordion Box-->
                    <ul class="accordion-box">
                    	
                        <!--Block-->
                        <li class="accordion block active-block">
                            <div class="acc-btn active"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>There are many many variations of passages of Lorem Ipsum available?</div>
                            <div class="acc-content current">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
						
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin?</div>
                            <div class="acc-content">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
                        
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>Lessons From just $20 Lessons for $120 or 10 Hours For $180?</div>
                            <div class="acc-content">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
                        
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>Aenean sollicitudin, lorem quis bibendum onsequat ipsum, ?</div>
                            <div class="acc-content">
                                <div class="content"><p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, dum auctor, nisi elit consequat ipsum, massa nisl quis neque.Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p></div>
                            </div>
                        </li>
						
                    </ul><!--End Accordion Box-->
                    
                </div>
                
            </div>
        </div>
    </section>
    <!--End Default Section-->
    
  <!--Main Footer-->
  <footer class="main-footer">
    <!--Widgets Section-->
    <div class="widgets-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Big Column-->
                <div class="big-column col-md-12 col-sm-12 col-xs-12">
                    <div class="row clearfix">
                    
                        <!--Footer Column-->
                        <div class="footer-column col-md-4 col-sm-6 col-xs-12">
                            <!--About Widget-->
                            <div class="footer-widget about-widget">
                                <div class="footer-logo">
                                    <a href="index.html"><img src="images/a2zlogo.png" alt="" /></a>
                                </div>
                                <div class="widget-content">
                                    <div class="bold-text">Our School Specialists!</div>
                                    <div class="text">Aorem ipsum dolor sit amet elit sed lum tempor incididunt ut labore el dolore alg minim veniam quis nostrud lorem psum dolor sit amet sed incididunt.</div>
                                    <!--<a href="#" class="read-more">Read More...</a>-->
                                </div>
                            </div>
                        </div>
                        
                        <!--Footer Column-->
                        <div class="footer-column col-md-4 col-sm-6 col-xs-12">
                            <!--Info Widget-->
                            <div class="footer-widget info-widget">
                                <h2>Keep in Touch</h2>
                                <div class="widget-content">
                                    <ul class="list-style-one">
                                        <li><span class="icon flaticon-location-pin"></span>Mattancherry Halt, Kochi CPSA<br>Building , CIFT Junction , W. Island<br>Kochi Pin- 682029</li>
                                        <li><span class="icon flaticon-technology-3"></span>8590085591, 9605885591</li>
                                        <li><span class="icon flaticon-interface"></span>mail@a2zinstituteofheavyequipments.com
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Footer Column-->
                        <div class="footer-column col-md-4 col-sm-6 col-xs-12">
                            <div class="footer-widget subscribe-widget">
                                <h2>News letter</h2>
                                <div class="widget-content">
                                    <div class="newsletter-form">
                                        <form method="post" action="contact.html">
                                            <div class="form-group">
                                                <input type="text" name="name" value="" placeholder="Name *" required="">
                                            </div>
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Email Id" required="">
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="theme-btn btn-style-one">SUBSCRIBE</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
                <!--Big Column-->
                <div class="big-column col-md-6 col-sm-12 col-xs-12">
                    <div class="row clearfix">
                        
                        
                        
                        
                        
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!--Footer Bottom-->
    <div class="footer-bottom">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="copyright">&copy; Copyright 2021 A2Z | All Rights Reserved</div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <ul class="social-links-two">
                        <li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="#"><span class="fab fa-youtube"></span></a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--End Main Footer-->
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>
<script src="js/owl.js"></script>
<script src="js/appear.js"></script>
<script src="js/wow.js"></script>
<script src="js/script.js"></script>

</body>
</html>